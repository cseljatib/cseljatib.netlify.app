#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Function: "xyBoxplot"                                             #
# It creates a scattterplot with boxplots for the Y variable
#  depending on ranges of the X-varibale      #
# How this function works?:                                            #
# > xyBoxplot(x, y, col.dots,...)   #
#                                                                      #
# Where:                                                               #
# - x: vector of variable X, or the predictor variable                                                   #
# - y: vector of variable Y, or the response variable
# - col.dots: string with color for the dots of the scatterplot X   #
#  - ylab, xlab:  these options can be specified as usual in R          #
#                                                                      #
# Created  by: Christian Salas-Eljatib                                 #
# Date: jun9, 2020                                                   # 
# Santiago, Chile                                                      #
#----------------------------------------------------------------------#
xyBoxplot<-function(x=x, y=y, col.dots="blue",
                 xlab=NULL, ylab=NULL){
  
  library("ggplot2")
  df <- data.frame(x,y)
  xrange <- x;  yrange <- y
  
  cls.x <- quantile(df$x, seq(.1, .9, by=.1))
  df$x.class <- findInterval(df$x, cls.x)
  df$x.class <- as.factor(df$x.class)
  
  p <- ggplot(df, aes(x, y, group=x.class))+#, fill="green")) + 
    geom_point(alpha = 0.10,col=col.dots)+ geom_boxplot(alpha = 0.10) 
  p + theme(legend.position = "none")  + #xlab(d.lab) + ylab(v.lab) +
    xlab(xlab) + ylab(ylab) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          panel.background = element_blank(), axis.line = element_line(colour = "black"))
  
  #par(my.par)
}
#---------------------------
##how to use this funcion?
#
#library(datana)
#data(fishgrowth)
#df <- fishgrowth
#xyBoxplot(x=df$age,y=df$length)
#xyBoxplot(x=df$length,y=df$scale, ylab="Variable Y",
#          xlab="Variable X")
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
